use toysgroup_vendite;

# Il fatturato di ciascuna vendita è stato calcolato nella seguente view 
create view Ricavo_vw as 
(select
v.idvendita
,v.idprodotto
,v.idregione
,v.datavendita
,p.prezzounitario
,v.quantità
,p.prezzounitario*v.quantità as Ricavo
from vendita as v
join prodotto as p on p.IDProdotto=v.IDProdotto);


#1) Verificare che i campi definiti come PK siano univoci

select count(idcategoria) as idCategoriaTot
,count(distinct idcategoria) as idCategoriaDist
from categoria;

select
count(idprodotto) as idProdottoTot
,count(distinct idprodotto) as IdProdottoDist
from prodotto;

select
count(idregione) as IdRegioneTot
,count(distinct idregione) as IdRegioneDist
from regione;

select
count(idvendita) as IdVenditaTot
,count(distinct idvendita) as IdVenditaDist
from vendita;

#2) Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno

select
p.idprodotto
,p.idcategoria
,p.nomeprodotto
,sum(r.ricavo) as Fatturato
,year(r.datavendita) as Anno
from
prodotto as p 
join ricavo_vw as r 
on p.idprodotto=r.idprodotto
group by p.idprodotto,year(r.datavendita)
order by fatturato desc;

#3) Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente.

select
reg.nomeregione as Stato
,sum(ric.ricavo) as Fatturato
,year(ric.datavendita) as Anno
from ricavo_vw as ric
join  regione as reg 
on ric.idregione=reg.idregione
group by Stato,Anno
order by Anno desc,Fatturato desc;

#4) qual è la categoria di articoli maggiormente richiesta dal mercato? 

select
c.NomeCategoria
,sum(v.quantità) as QuantitàVenduta
from vendita as v
join prodotto as p on v.idprodotto=p.idprodotto
join categoria as c on p.idcategoria=c.idcategoria
group by NomeCategoria
order by QuantitàVenduta desc
limit 1;

#5) quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.

select
p.idprodotto
,p.nomeprodotto
from prodotto as p
left join vendita as v on p.idprodotto=v.idprodotto
where v.idprodotto is null;

select
p.idprodotto
,p.nomeprodotto
from prodotto as p
where p.idprodotto not in 
(select v.idprodotto from vendita as v);

#6) Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente).

select
p.idprodotto
,p.nomeprodotto
,max(v.datavendita) as UltimaVendita
from vendita as v
join prodotto as p on v.idprodotto=p.idprodotto
group by p.idprodotto;

#Query aggiuntive
#Categoria con fatturato totale maggiore
select
c.NomeCategoria
,sum(r.ricavo) as FatturatoMax
from ricavo_vw as r 
join prodotto as p
on r.idprodotto=p.idprodotto
join categoria as c
on p.idcategoria=c.idcategoria
group by c.nomecategoria
order by FatturatoMax desc
limit 1;

#Anno con fatturato totale maggiore

select 
sum(r.ricavo) as FatturatoMAX
,year(r.datavendita) as Anno
from ricavo_vw as r
group by Anno
order by FatturatoMAX desc
limit 1;

#Stato con fatturato totale maggiore

select 
sum(r.ricavo) as FatturatoMAX
,reg.nomeregione as Stato
from ricavo_vw as r
join regione as reg 
on r.idregione=reg.idregione
group by reg.nomeregione
order by FatturatoMAX desc
limit 1;

#Media vendite per categoria in ciascuno Stato 

select
r.nomeregione
,c.nomecategoria
,avg(v.quantità) as MediaQuantità
from vendita as v
join prodotto as p
on v.idprodotto=p.idprodotto
join regione as r 
on v.idregione=r.idregione
join categoria as c on p.idcategoria=c.idcategoria
group by c.nomecategoria, r.nomeregione;

#Prodotto piu venduto in quale stato e anno

select
p.nomeprodotto
,sum(v.quantità) as QuantitàVenditaMAX
,r.nomeregione as Stato
,year(v.datavendita) as Anno
from vendita as v
join prodotto as p
on v.idprodotto=p.idprodotto
join regione as r 
on v.idregione=r.idregione
group by p.nomeprodotto, r.nomeregione,year(v.datavendita)
order by QuantitàVenditaMAX desc
limit 1;

#Prodotto piu venduto tra marzo 2020 e dicembre 2020

select
p.idprodotto
,p.nomeprodotto 
,sum(v.quantità) as Quantità
from vendita as v
join prodotto as p 
on v.idprodotto=p.idprodotto
where v.datavendita between '2020-01-01' and '2020-12-31'
group by p.idprodotto
order by Quantità desc
limit 1;

#categorie vendute in ordine decrescente ordinate per mese e anno

select
c.nomecategoria
,sum(v.quantità) as Qvenduta
,monthname(v.datavendita) as Mese
,year(v.datavendita) as Anno
from vendita as v
join prodotto as p on v.idprodotto=p.idprodotto
join categoria as c on  p.idcategoria=c.idcategoria
group by c.nomecategoria, monthname(v.datavendita),year(v.datavendita)
order by Qvenduta desc;

#IL numero di prodotti venduti in ogni stato in ordine decrescente suddivisi per anni

select
count(distinct v.idprodotto) as NumProdotti
,r.nomeregione
,year(v.datavendita)
from prodotto as p
join vendita as v on p.idprodotto=v.idprodotto
join regione as r on v.idregione=r.idregione
group by r.nomeregione,year(v.datavendita)
order by NumProdotti desc;

#Lo stato che ha fatturato di piu nel periodo tra una settimana prima e una settimana dopo Natale

select
reg.nomeregione
,sum(ri.ricavo) as FatturatoMax
from ricavo_vw as ri
join regione as reg on ri.idregione=reg.idregione
where
ri.DataVendita BETWEEN SUBDATE(DATE_FORMAT(ri.DataVendita, '%Y-12-25'), 7) 
AND ADDDATE(DATE_FORMAT(ri.DataVendita, '%Y-12-25'), 7)
group by reg.nomeregione
order by FatturatoMax desc
limit 1;