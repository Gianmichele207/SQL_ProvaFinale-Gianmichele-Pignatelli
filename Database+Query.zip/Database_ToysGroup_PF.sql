-- Creazione del database
CREATE DATABASE ToysGroup_Vendite;

-- Selezioniamo il database appena creato
USE ToysGroup_Vendite;

-- Creazione della tabella Categoria
CREATE TABLE Categoria (
    IDCategoria INT AUTO_INCREMENT PRIMARY KEY,
    NomeCategoria VARCHAR(100) NOT NULL
);

-- Creazione della tabella Prodotto
CREATE TABLE Prodotto (
    IDProdotto INT AUTO_INCREMENT PRIMARY KEY,
    NomeProdotto VARCHAR(100) NOT NULL,
    IDCategoria INT,
    FOREIGN KEY (IDCategoria) REFERENCES Categoria(IDCategoria)
);

-- Creazione della tabella Regione
CREATE TABLE Regione (
    IDRegione INT AUTO_INCREMENT PRIMARY KEY,
    NomeRegione VARCHAR(100) NOT NULL
);

-- Creazione della tabella Vendita
CREATE TABLE Vendita (
    IDVendita INT AUTO_INCREMENT PRIMARY KEY,
    DataVendita DATE NOT NULL,
    PrezzoUnitario DECIMAL(10, 2) NOT NULL,
    Quantità INT NOT NULL,
    Ricavo DECIMAL(10, 2) AS (PrezzoUnitario * Quantità) STORED,
    IDProdotto INT,
    IDRegione INT,
    FOREIGN KEY (IDProdotto) REFERENCES Prodotto(IDProdotto),
    FOREIGN KEY (IDRegione) REFERENCES Regione(IDRegione)
);

#Popolamento della tabella Categoria con 10 categorie di esempio

INSERT INTO Categoria (NomeCategoria)
VALUES
('Giocattoli Educativi'), #1
('Puzzle'),               #2  
('Costruzioni'),          #3
('Veicoli Giocattolo'),   #4
('Giochi da Tavolo'),     #5
('Peluche'),              #6
('Bambole e Accessori'),  #7
('Giocattoli Telecomandati'), #8
('Giochi Creativi'),          #9
('Giochi Scientifici');       #10

-- Popolamento della tabella Prodotto con 100 prodotti associati alle categorie
INSERT INTO Prodotto (NomeProdotto, IDCategoria)
VALUES
('Abaco Educativo', 1),          
('Piano Musicale per Bambini', 1), 
('Puzzle in Legno', 2),            
('Puzzle 1000 Pezzi', 2),         
('Set di Costruzioni in Plastica', 3),  
('Torre di Blocchi da Costruzione', 3), 
('Macchinina Telecomandata', 4),   
('Aeroplano Telecomandato', 4),   
('Monopoli', 5),                 
('Scacchi Tradizionali', 5),      
('Orsetto di Peluche', 6),        
('Cuscino Peluche', 6),        
('Set di Matematica Interattivo', 1),
('Libro Interattivo per Bambini', 1),
('Tavoletta Magica per Disegno', 1),
('Gioco delle Parole Educativo', 1),
('Gioco Educativo ABC', 1),
('Puzzle Animali della Savana', 2),
('Puzzle Mappa del Mondo', 2),
('Puzzle 3D Castello Medioevale', 2),
('Puzzle 500 pezzi Paesaggi', 2),
('Puzzle 1000 pezzi Van Gogh', 2),
('Set Lego Classic', 3),
('Costruzioni in Legno Naturale', 3),
('Costruzioni Magnetiche Colorate', 3),
('Costruzioni Torre Eiffel', 3),
('Set Lego Technic Auto', 3),
('Auto da Corsa Telecomandata', 4),
('Macchinina Vintage in Metallo', 4),
('Trattore con Rimorchio', 4),
('Camion dei Vigili del Fuoco', 4),
('Moto da Cross Giocattolo', 4),
('Gioco da Tavolo Monopoli', 5),
('Gioco da Tavolo Cluedo', 5),
('Gioco da Tavolo Dixit', 5),
('Gioco da Tavolo Risiko', 5),
('Gioco da Tavolo Scarabeo', 5),
('Peluche Orso Morbido', 6),
('Peluche Coniglio Dolcissimo', 6),
('Peluche Gatto Bianco', 6),
('Peluche Unicorno Arcobaleno', 6),
('Peluche Pinguino Polare', 6),
('Bambola con Abiti Principeschi', 7),
('Bambola da Collezione', 7),
('Set di Accessori per Bambole', 7),
('Casa delle Bambole Deluxe', 7),
('Cucina Giocattolo con Luci', 7),
('Elicottero Telecomandato', 8),
('Drone Giocattolo per Bambini', 8),
('Auto Telecomandata Off-Road', 8),
('Barca Telecomandata', 8),
('Aereo Telecomandato con LED', 8),
('Set di Pittura Creativo', 9),
('Kit di Argilla per Modellare', 9),
('Set di Disegno Completo', 9),
('Kit di Scrapbooking per Bambini', 9),
('Set di Braccialetti Fai-da-te', 9),
('Microscopio Educativo', 10),
('Kit di Chimica per Esperimenti', 10),
('Telescope per Bambini', 10),
('Laboratorio Scientifico', 10),
('Set di Geologia con Rocce', 10),
('Gioco Educativo Lettura e Scrittura', 1),
('Tappeto Educativo Interattivo', 1),
('Puzzle Spaziale 3D', 2),
('Puzzle Piramidi d’Egitto', 2),
('Costruzioni Base Castello', 3),
('Costruzioni Base Robot', 3),
('Macchina da Corsa Giocattolo', 4),
('Set di Camion e Escavatore', 4),
('Tavolo Multigioco', 5),
('Gioco di Carte Uno', 5),
('Peluche Tigre Gigante', 6),
('Peluche Panda Abbraccioso', 6),
('Bambola Parlante con Frasi', 7),
('Bambola Sirena Magica', 7),
('Auto della Polizia Telecomandata', 8),
('Camion dei Pompieri Telecomandato', 8),
('Set di Pastelli e Colori', 9),
('Set per Pittura ad Acquerello', 9),
('Microscopio Portatile', 10),
('Gioco di Carte Dobble', 5),
('Gioco di Carte Magic', 5),
('Set di Chimica Avanzato', 10),
('Puzzle Dino 3D', 2),
('Puzzle Città Futuristica', 2),
('Costruzioni Ponte Ingegnoso', 3),
('Treno Classico Giocattolo', 4),
('Moto Elettrica per Bambini', 4),
('Kit Fai-da-te per Modellini', 9),
('Set di Argilla per Bambini', 9),
('Microscopio Professionale', 10),
('Laboratorio di Robotica', 10),
('Puzzle Magnetico per Bambini', 2),
('Set di Giochi Educativi Completo', 1),
('Puzzle 3D Torre Eiffel', 2),
('Bambola con Accessori Moderni', 7),
('Auto Telecomandata con Accessori', 8),
('Kit di Pittura con Cavalletto', 9),
('Laboratorio Chimico Completo', 10);

-- Popolamento della tabella Regione con 20 stati
INSERT INTO Regione (NomeRegione)
VALUES
('Italia'),
('Francia'),
('Germania'),
('Spagna'),
('Regno Unito'),
('Stati Uniti'),
('Canada'),
('Messico'),
('Brasile'),
('Argentina'),
('Australia'),
('Giappone'),
('Cina'),
('India'),
('Russia'),
('Sudafrica'),
('Egitto'),
('Turchia'),
('Corea del Sud'),
('Nuova Zelanda');


-- Aggiunta di 300 record nella tabella Vendita
INSERT INTO Vendita (DataVendita, PrezzoUnitario, Quantità, IDProdotto, IDRegione)
SELECT
    -- Generazione della data casuale tra 2019 e 2023
    DATE_ADD('2019-01-01', INTERVAL FLOOR(RAND() * 1826) DAY) AS DataVendita,
    
    -- Prezzo casuale tra 5 e 100 euro
    ROUND(5 + (RAND() * (100 - 5)), 2) AS PrezzoUnitario,
    
    -- Quantità casuale tra 1 e 10
    FLOOR(1 + (RAND() * 10)) AS Quantità,
    
    -- Selezione di un prodotto da IDProdotto tra 1 e 93 (evita gli ID da 94 a 100)
    FLOOR(RAND() * 93) + 1 AS IDProdotto,
    
    -- Selezione casuale di una regione
    FLOOR(RAND() * 20) + 1 AS IDRegione
FROM 
    -- Seleziona 300 righe
    (SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL 
     SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10 UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL 
     SELECT 13 UNION ALL SELECT 14 UNION ALL SELECT 15 UNION ALL SELECT 16 UNION ALL SELECT 17 UNION ALL SELECT 18 UNION ALL 
     SELECT 19 UNION ALL SELECT 20 UNION ALL SELECT 21 UNION ALL SELECT 22 UNION ALL SELECT 23 UNION ALL SELECT 24 UNION ALL 
     SELECT 25 UNION ALL SELECT 26 UNION ALL SELECT 27 UNION ALL SELECT 28 UNION ALL SELECT 29 UNION ALL SELECT 30 UNION ALL 
     SELECT 31 UNION ALL SELECT 32 UNION ALL SELECT 33 UNION ALL SELECT 34 UNION ALL SELECT 35 UNION ALL SELECT 36 UNION ALL 
     SELECT 37 UNION ALL SELECT 38 UNION ALL SELECT 39 UNION ALL SELECT 40 UNION ALL SELECT 41 UNION ALL SELECT 42 UNION ALL 
     SELECT 43 UNION ALL SELECT 44 UNION ALL SELECT 45 UNION ALL SELECT 46 UNION ALL SELECT 47 UNION ALL SELECT 48 UNION ALL 
     SELECT 49 UNION ALL SELECT 50 UNION ALL SELECT 51 UNION ALL SELECT 52 UNION ALL SELECT 53 UNION ALL SELECT 54 UNION ALL 
     SELECT 55 UNION ALL SELECT 56 UNION ALL SELECT 57 UNION ALL SELECT 58 UNION ALL SELECT 59 UNION ALL SELECT 60 UNION ALL 
     SELECT 61 UNION ALL SELECT 62 UNION ALL SELECT 63 UNION ALL SELECT 64 UNION ALL SELECT 65 UNION ALL SELECT 66 UNION ALL 
     SELECT 67 UNION ALL SELECT 68 UNION ALL SELECT 69 UNION ALL SELECT 70 UNION ALL SELECT 71 UNION ALL SELECT 72 UNION ALL 
     SELECT 73 UNION ALL SELECT 74 UNION ALL SELECT 75 UNION ALL SELECT 76 UNION ALL SELECT 77 UNION ALL SELECT 78 UNION ALL 
     SELECT 79 UNION ALL SELECT 80 UNION ALL SELECT 81 UNION ALL SELECT 82 UNION ALL SELECT 83 UNION ALL SELECT 84 UNION ALL 
     SELECT 85 UNION ALL SELECT 86 UNION ALL SELECT 87 UNION ALL SELECT 88 UNION ALL SELECT 89 UNION ALL SELECT 90 UNION ALL 
     SELECT 91 UNION ALL SELECT 92 UNION ALL SELECT 93 UNION ALL SELECT 94 UNION ALL SELECT 95 UNION ALL SELECT 96 UNION ALL 
     SELECT 97 UNION ALL SELECT 98 UNION ALL SELECT 99 UNION ALL SELECT 100 UNION ALL SELECT 101 UNION ALL SELECT 102 UNION ALL 
     SELECT 103 UNION ALL SELECT 104 UNION ALL SELECT 105 UNION ALL SELECT 106 UNION ALL SELECT 107 UNION ALL SELECT 108 UNION ALL 
     SELECT 109 UNION ALL SELECT 110 UNION ALL SELECT 111 UNION ALL SELECT 112 UNION ALL SELECT 113 UNION ALL SELECT 114 UNION ALL 
     SELECT 115 UNION ALL SELECT 116 UNION ALL SELECT 117 UNION ALL SELECT 118 UNION ALL SELECT 119 UNION ALL SELECT 120 UNION ALL 
     SELECT 121 UNION ALL SELECT 122 UNION ALL SELECT 123 UNION ALL SELECT 124 UNION ALL SELECT 125 UNION ALL SELECT 126 UNION ALL 
     SELECT 127 UNION ALL SELECT 128 UNION ALL SELECT 129 UNION ALL SELECT 130 UNION ALL SELECT 131 UNION ALL SELECT 132 UNION ALL 
     SELECT 133 UNION ALL SELECT 134 UNION ALL SELECT 135 UNION ALL SELECT 136 UNION ALL SELECT 137 UNION ALL SELECT 138 UNION ALL 
     SELECT 139 UNION ALL SELECT 140 UNION ALL SELECT 141 UNION ALL SELECT 142 UNION ALL SELECT 143 UNION ALL SELECT 144 UNION ALL 
     SELECT 145 UNION ALL SELECT 146 UNION ALL SELECT 147 UNION ALL SELECT 148 UNION ALL SELECT 149 UNION ALL SELECT 150 UNION ALL 
     SELECT 151 UNION ALL SELECT 152 UNION ALL SELECT 153 UNION ALL SELECT 154 UNION ALL SELECT 155 UNION ALL SELECT 156 UNION ALL 
     SELECT 157 UNION ALL SELECT 158 UNION ALL SELECT 159 UNION ALL SELECT 160 UNION ALL SELECT 161 UNION ALL SELECT 162 UNION ALL 
     SELECT 163 UNION ALL SELECT 164 UNION ALL SELECT 165 UNION ALL SELECT 166 UNION ALL SELECT 167 UNION ALL SELECT 168 UNION ALL 
     SELECT 169 UNION ALL SELECT 170 UNION ALL SELECT 171 UNION ALL SELECT 172 UNION ALL SELECT 173 UNION ALL SELECT 174 UNION ALL 
     SELECT 175 UNION ALL SELECT 176 UNION ALL SELECT 177 UNION ALL SELECT 178 UNION ALL SELECT 179 UNION ALL SELECT 180 UNION ALL 
     SELECT 181 UNION ALL SELECT 182 UNION ALL SELECT 183 UNION ALL SELECT 184 UNION ALL SELECT 185 UNION ALL SELECT 186 UNION ALL 
     SELECT 187 UNION ALL SELECT 188 UNION ALL SELECT 189 UNION ALL SELECT 190 UNION ALL SELECT 191 UNION ALL SELECT 192 UNION ALL 
     SELECT 193 UNION ALL SELECT 194 UNION ALL SELECT 195 UNION ALL SELECT 196 UNION ALL SELECT 197 UNION ALL SELECT 198 UNION ALL 
     SELECT 199 UNION ALL SELECT 200 UNION ALL SELECT 201 UNION ALL SELECT 202 UNION ALL SELECT 203 UNION ALL SELECT 204 UNION ALL 
     SELECT 205 UNION ALL SELECT 206 UNION ALL SELECT 207 UNION ALL SELECT 208 UNION ALL SELECT 209 UNION ALL SELECT 210 UNION ALL 
     SELECT 211 UNION ALL SELECT 212 UNION ALL SELECT 213 UNION ALL SELECT 214 UNION ALL SELECT 215 UNION ALL SELECT 216 UNION ALL 
     SELECT 217 UNION ALL SELECT 218 UNION ALL SELECT 219 UNION ALL SELECT 220 UNION ALL SELECT 221 UNION ALL SELECT 222 UNION ALL 
     SELECT 223 UNION ALL SELECT 224 UNION ALL SELECT 225 UNION ALL SELECT 226 UNION ALL SELECT 227 UNION ALL SELECT 228 UNION ALL 
     SELECT 229 UNION ALL SELECT 230 UNION ALL SELECT 231 UNION ALL SELECT 232 UNION ALL SELECT 233 UNION ALL SELECT 234 UNION ALL 
     SELECT 235 UNION ALL SELECT 236 UNION ALL SELECT 237 UNION ALL SELECT 238 UNION ALL SELECT 239 UNION ALL SELECT 240 UNION ALL 
     SELECT 241 UNION ALL SELECT 242 UNION ALL SELECT 243 UNION ALL SELECT 244 UNION ALL SELECT 245 UNION ALL SELECT 246 UNION ALL 
     SELECT 247 UNION ALL SELECT 248 UNION ALL SELECT 249 UNION ALL SELECT 250 UNION ALL SELECT 251 UNION ALL SELECT 252 UNION ALL 
     SELECT 253 UNION ALL SELECT 254 UNION ALL SELECT 255 UNION ALL SELECT 256 UNION ALL SELECT 257 UNION ALL SELECT 258 UNION ALL 
     SELECT 259 UNION ALL SELECT 260 UNION ALL SELECT 261 UNION ALL SELECT 262 UNION ALL SELECT 263 UNION ALL SELECT 264 UNION ALL 
     SELECT 265 UNION ALL SELECT 266 UNION ALL SELECT 267 UNION ALL SELECT 268 UNION ALL SELECT 269 UNION ALL SELECT 270 UNION ALL 
     SELECT 271 UNION ALL SELECT 272 UNION ALL SELECT 273 UNION ALL SELECT 274 UNION ALL SELECT 275 UNION ALL SELECT 276 UNION ALL 
     SELECT 277 UNION ALL SELECT 278 UNION ALL SELECT 279 UNION ALL SELECT 280 UNION ALL SELECT 281 UNION ALL SELECT 282 UNION ALL 
     SELECT 283 UNION ALL SELECT 284 UNION ALL SELECT 285 UNION ALL SELECT 286 UNION ALL SELECT 287 UNION ALL SELECT 288 UNION ALL 
     SELECT 289 UNION ALL SELECT 290 UNION ALL SELECT 291 UNION ALL SELECT 292 UNION ALL SELECT 293 UNION ALL SELECT 294 UNION ALL 
     SELECT 295 UNION ALL SELECT 296 UNION ALL SELECT 297 UNION ALL SELECT 298 UNION ALL SELECT 299 UNION ALL SELECT 300) AS Numbers;




